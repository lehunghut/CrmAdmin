<!DOCTYPE html>
<html>

@include('la.layouts.partials.htmlheader')

@yield('content')

</html>